"use client";

import React, { useState } from "react";
import FooterNine from "../layout/footers/FooterNine";

export default function QuizClient() {
  const questions = [
    {
      id: 1,
      text: "Ce apreciezi cel mai mult într-o relație?",
      options: ["Încrederea", "Comunicarea", "Respectul reciproc"],
      type: "single",
      next: {
        Încrederea: 2,
        Comunicarea: 3,
        "Respectul reciproc": 4,
      },
    },
    {
      id: 2,
      text: "Cât de des preferi să comunici cu partenerul tău?",
      options: ["Zilnic", "Săptămânal", "Ocazional"],
      type: "single",
      next: {
        Zilnic: 5,
        Săptămânal: 6,
        Ocazional: 4,
      },
    },
    {
      id: 3,
      text: "Care este cel mai important aspect într-o discuție?",
      options: ["Ascultarea", "Empatia", "Claritatea mesajului"],
      type: "single",
      next: {
        Ascultarea: 7,
        Empatia: 5,
        "Claritatea mesajului": 6,
      },
    },
    {
      id: 4,
      text: "Care este activitatea preferată pe care v-ar plăcea să o faceți împreună?",
      options: ["Călătorii", "Sporturi", "Gătit", "Relaxare acasă"],
      type: "single",
      next: {
        Călătorii: 8,
        Sporturi: 5,
        Gătit: 6,
        "Relaxare acasă": 7,
      },
    },
    {
      id: 5,
      text: "Ce valori considerați importante într-o relație?",
      options: ["Sinceritatea", "Loialitatea", "Sprijinul", "Libertatea"],
      type: "multiple",
      next: {
        default: 9,
      },
    },
    {
      id: 6,
      text: "Cât de mult contează timpul petrecut împreună?",
      options: ["Foarte mult", "Destul de mult", "Mai puțin important"],
      type: "single",
      next: {
        "Foarte mult": 9,
        "Destul de mult": 8,
        "Mai puțin important": 7,
      },
    },
    {
      id: 7,
      text: "Ce înseamnă pentru tine sprijinul într-o relație?",
      options: ["Susținere morală", "Ajutor financiar", "Ambiție comună"],
      type: "single",
      next: {
        "Susținere morală": 8,
        "Ajutor financiar": 9,
        "Ambiție comună": 10,
      },
    },
    {
      id: 8,
      text: "Cât de importantă este independența într-o relație?",
      options: ["Foarte importantă", "Importantă", "Mai puțin importantă"],
      type: "single",
      next: {
        "Foarte importantă": 10,
        Importantă: 9,
        "Mai puțin importantă": null,
      },
    },
    {
      id: 9,
      text: "Care dintre aceste caracteristici este esențială pentru tine?",
      options: ["Respect", "Încredere", "Onestitate", "Toleranță"],
      type: "multiple",
      next: {
        default: 10,
      },
    },
    {
      id: 10,
      text: "Cum preferi să fie abordate problemele într-o relație?",
      options: ["Discuții deschise", "Compromis", "Evitat pe moment"],
      type: "single",
      next: {
        "Discuții deschise": null,
        Compromis: null,
        "Evitat pe moment": null,
      },
    },
  ];

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOptions, setSelectedOptions] = useState({});
  const [progress, setProgress] = useState(0);

  const currentQuestion = questions[currentQuestionIndex];

  const handleOptionChange = (option) => {
    if (currentQuestion.type === "multiple") {
      setSelectedOptions((prev) => {
        const options = prev[currentQuestion.id] || [];
        if (options.includes(option)) {
          return {
            ...prev,
            [currentQuestion.id]: options.filter((o) => o !== option),
          };
        } else {
          return { ...prev, [currentQuestion.id]: [...options, option] };
        }
      });
    } else {
      setSelectedOptions((prev) => ({
        ...prev,
        [currentQuestion.id]: option,
      }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const selectedAnswer = selectedOptions[currentQuestion.id];

    let nextQuestionId;
    if (currentQuestion.type === "multiple") {
      nextQuestionId = currentQuestion.next.default;
    } else {
      nextQuestionId =
        currentQuestion.next[selectedAnswer] || currentQuestion.next.default;
    }

    const nextQuestionIndex = questions.findIndex(
      (q) => q.id === nextQuestionId
    );

    if (nextQuestionIndex !== -1) {
      setCurrentQuestionIndex(nextQuestionIndex);
      setProgress(((nextQuestionIndex + 1) / questions.length) * 100);
    } else {
      console.log("Chestionar finalizat");
    }
  };

  return (
    <div className="dashboard__main pl-0">
      <div className="dashboard__content bg-light-4">
        <div className="row pb-50 mb-10">
          <div className="col-auto">
            <h1 className="text-30 lh-12 fw-700">Chestionar</h1>
          </div>
        </div>

        <div className="row y-gap-30">
          <div className="col-xl-9">
            <div className="rounded-16 bg-white -dark-bg-dark-1 shadow-4">
              <div className="py-30 px-30">
                <div className="border-light overflow-hidden rounded-8">
                  <div className="py-40 px-40 bg-dark-5">
                    {/* <h4 className="text-18 lh-1 fw-500 text-white">
                      Întrebarea {currentQuestion.id}
                    </h4> */}
                    <div className="text-20 lh-1 text-white mt-15">
                      {currentQuestion.text}
                    </div>
                  </div>
                  <div className="px-40 py-40">
                    <form onSubmit={handleSubmit}>
                      {currentQuestion.options.map((option, index) => (
                        <div
                          key={index}
                          className="form-radio d-flex items-center mt-20"
                        >
                          <div className="radio">
                            <input
                              type={
                                currentQuestion.type === "multiple"
                                  ? "checkbox"
                                  : "radio"
                              }
                              value={option}
                              checked={
                                currentQuestion.type === "multiple"
                                  ? selectedOptions[
                                      currentQuestion.id
                                    ]?.includes(option)
                                  : selectedOptions[currentQuestion.id] ===
                                    option
                              }
                              onChange={() => handleOptionChange(option)}
                            />
                            <div className="radio__mark">
                              <div className="radio__icon"></div>
                            </div>
                          </div>
                          <div className="fw-500 ml-12">{option}</div>
                        </div>
                      ))}
                      <div className="d-flex justify-end">
                        <button
                          type="submit"
                          className="button -md -dark-1 text-white -dark-button-white mt-40"
                        >
                          Următorul
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
              <div className="d-flex justify-between items-center mt-40"></div>
            </div>
          </div>

          <div className="col-xl-3 col-lg-3">
            <div className="row y-gap-30">
              <div className="col-12">
                <div className="pt-20 pb-30 px-30 rounded-16 bg-white -dark-bg-dark-1 shadow-4">
                  <h5 className="text-17 fw-500 mb-30">Progres chestionar</h5>
                  <div className="d-flex items-center">
                    <div className="progress-bar w-1/1">
                      <div className="progress-bar__bg bg-light-3"></div>
                      <div
                        className="progress-bar__bar bg-purple-1"
                        style={{ width: `${progress}%` }}
                      ></div>
                    </div>
                    <div className="d-flex y-gap-10 justify-between items-center ml-15">
                      <div>{progress.toFixed(0)}%</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <FooterNine />
    </div>
  );
}
